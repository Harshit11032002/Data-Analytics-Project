create database Branch_analytics;
use Branch_analytics;
select * from brokerage;
select * from fees;

#1 No of Invoice by Account Exec
select * from invoice;
select `Account Executive`, count(invoice_number) as No_of_invoice
from invoice
group by `Account Executive` order by No_of_invoice desc;

#2 Yearly Meeting Count
select * from meeting;
select year(str_to_date(meeting_date,'%d-%m-%Y'))as meeting_Year,
count(*) as meeting_count
from meeting
group by year(str_to_date(meeting_date,'%d-%m-%Y')) order by meeting_year;

#3 Cross Sell--Target, Achieve, new
select * from `individual budget`;
select 
(select sum(`Cross sell Budget`) from `individual budget`)  as target,
(select sum(Amount) from brokerage where income_class= 'Cross Sell')
+ (select sum(Amount) from fees where income_class= 'Cross Sell') As achievement,
(select sum(Amount) from invoice where income_class= 'Cross Sell') as invoice;

#3 New-Target,Achive,new
select * from `individual budget`;
select 
(select sum(`New Budget`) from `individual budget`)  as target,
(select sum(Amount) from brokerage where income_class= 'New')
+ (select sum(Amount) from fees where income_class= 'New') As achievement,
(select sum(Amount) from invoice where income_class= 'New') as invoice;

#3 Renewal-Target, Achieve,new
select * from `individual budget`;
select 
(select sum(`Renewal Budget`) from `individual budget`) as target,
(select sum(Amount) from brokerage where income_class= 'Renewal')
+ (select sum(Amount) from fees where income_class= 'Renewal') As achievement,
(select sum(Amount) from invoice where income_class= 'Renewal') as invoice;

#4 Stage Funnel by Revenue
select * from opportunity;
select stage, sum(revenue_amount) as total from opportunity
group by stage;

#5 No of meeting By Account Exe
select * from meeting;
select `Account Executive`, count(meeting_date) as No_of_meetings
from meeting
group by `Account Executive` order by No_of_meetings desc;

#6 Top Open Opportunity by Revenue
select * from opportunity;
select opportunity_name, sum(revenue_amount)
from opportunity
group by opportunity_name 
order by sum(revenue_amount) desc 
limit 4;


#7 Top 4 open opportunity
select * from opportunity;
select distinct opportunity_name, sum(premium_amount) from opportunity
where stage in("Qualify opportunity", "propose solution")
group by opportunity_name order by sum(premium_amount) desc limit 4;

#8 Opportunity product distribution
select * from opportunity;
select count(opportunity_id),product_group from opportunity
group by product_group order by count(opportunity_id) desc;

#9Total opportunity and open opportunity count
Select count(opportunity_name) as Total_opportunity from opportunity;
Select count(opportunity_name) as open_opportunity from opportunity
where stage in ("Qualify Opportunity","Propose Solution");
